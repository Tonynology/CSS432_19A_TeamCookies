#!/bin/bash

g++ -o client.out Client.cpp -pthread
