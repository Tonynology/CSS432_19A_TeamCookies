#!/bin/bash

g++ -o server.out Server.cpp -pthread
