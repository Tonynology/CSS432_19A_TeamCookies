#!/bin/bash

g++ -o player.out Player.cpp -pthread
